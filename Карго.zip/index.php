<?php
require 'config.php';
$news = mysqli_query($conn, "SELECT * FROM news ORDER BY created_at DESC LIMIT 5");
$count_query = mysqli_query($conn, "SELECT COUNT(*) as total FROM barcodes");
$count = mysqli_fetch_assoc($count_query)['total'];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>9КМкарго - Доставка грузов из Китая</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
    <header class="bg-primary text-white text-center py-3">
        <h1><i class="bi bi-truck"></i> 9КМкарго</h1>
        <p>Доставка грузов из Китая</p>
    </header>
    <div class="container my-5">
        <h2>Проверка штрих-кода</h2>
        <p class="text-muted">Общее количество штрих-кодов: <strong><?php echo $count; ?></strong></p>
        <form id="barcodeForm">
            <div class="mb-3">
                <label for="barcodes" class="form-label">Введите штрих-коды (до 100, каждый с новой строки):</label>
                <textarea id="barcodes" name="barcodes" class="form-control" rows="5" placeholder="Введите штрих-коды, например:
123456789
987654321" maxlength="5000" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary"><i class="bi bi-search"></i> Проверить</button>
        </form>
        <div id="result" class="mt-3"></div>

        <h2 class="mt-5">Новости</h2>
        <?php if (mysqli_num_rows($news) > 0): ?>
            <?php while ($row = mysqli_fetch_assoc($news)): ?>
                <div class="card mb-3">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo htmlspecialchars($row['title']); ?></h5>
                        <p class="card-text"><?php echo htmlspecialchars($row['content']); ?></p>
                        <p class="text-muted"><?php echo $row['created_at']; ?></p>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>Новостей пока нет.</p>
        <?php endif; ?>
    </div>
    <footer class="bg-dark text-white text-center py-3">
        <p><i class="bi bi-geo-alt"></i> Адрес: Душанбе, 9КМ (около кафе Шаурма)</p>
        <p><i class="bi bi-telephone"></i> Контакты: +992 405444444 (WhatsApp, Telegram)</p>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/script.js"></script>
</body>
</html>