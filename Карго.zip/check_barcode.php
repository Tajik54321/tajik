<?php
header('Content-Type: application/json');
require 'config.php';

$barcodes_input = $_POST['barcodes'] ?? '';
if (empty($barcodes_input)) {
    echo json_encode(['error' => 'Введите штрих-коды']);
    exit;
}

// Разделяем штрих-коды по строкам
$barcodes = array_filter(array_map('trim', explode("\n", $barcodes_input)));
if (empty($barcodes)) {
    echo json_encode(['error' => 'Введите штрих-коды']);
    exit;
}

// Ограничение до 100 штрих-кодов
if (count($barcodes) > 100) {
    echo json_encode(['error' => 'Максимум 100 штрих-кодов за раз']);
    exit;
}

// Подготавливаем запрос для проверки
$results = [];
foreach ($barcodes as $barcode) {
    if (empty($barcode)) continue;
    $stmt = $conn->prepare("SELECT barcode, status, date FROM barcodes WHERE barcode = ?");
    $stmt->bind_param("s", $barcode);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $results[$barcode] = $row;
    } else {
        $results[$barcode] = ['error' => 'Штрих-код не найден'];
    }
    $stmt->close();
}

echo json_encode($results);
?>