<?php
if (file_exists('../config.php')) {
    die("Сайт уже установлен. Удалите папку install.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $host = $_POST['host'];
    $user = $_POST['user'];
    $pass = $_POST['pass'];
    $name = $_POST['name'];

    // Создаем config.php
    $config = "<?php
define('DB_HOST', '$host');
define('DB_USER', '$user');
define('DB_PASS', '$pass');
define('DB_NAME', '$name');

\$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if (!\$conn) {
    die('Connection failed: ' . mysqli_connect_error());
}
?>";
    file_put_contents('../config.php', $config);

    // Подключаемся к базе данных
    $conn = mysqli_connect($host, $user, $pass);
    if (!$conn) {
        die("Ошибка подключения: " . mysqli_connect_error());
    }

    // Создаем базу данных
    mysqli_query($conn, "CREATE DATABASE IF NOT EXISTS $name");
    mysqli_select_db($conn, $name);

    // Создаем таблицы
    $sql = "
    CREATE TABLE barcodes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        barcode VARCHAR(50) UNIQUE NOT NULL,
        status VARCHAR(100) NOT NULL,
        date DATETIME NOT NULL
    );
    CREATE TABLE news (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        content TEXT NOT NULL,
        created_at DATETIME NOT NULL
    );
    CREATE TABLE admins (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL
    );
    INSERT INTO admins (username, password) VALUES ('admin', '" . password_hash('admin123', PASSWORD_DEFAULT) . "');
    ";
    mysqli_multi_query($conn, $sql);
    while (mysqli_next_result($conn)) { } // Ожидаем завершения всех запросов

    echo "Установка завершена! Удалите папку install.";
    exit;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Установка 9КМкарго</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>Установка 9КМкарго</h1>
        <form method="POST">
            <div class="mb-3">
                <label>Хост базы данных</label>
                <input type="text" name="host" class="form-control" value="localhost" required>
            </div>
            <div class="mb-3">
                <label>Имя пользователя БД</label>
                <input type="text" name="user" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Пароль БД</label>
                <input type="password" name="pass" class="form-control">
            </div>
            <div class="mb-3">
                <label>Имя базы данных</label>
                <input type="text" name="name" class="form-control" value="9kmcargo" required>
            </div>
            <button type="submit" class="btn btn-primary">Установить</button>
        </form>
    </div>
</body>
</html>