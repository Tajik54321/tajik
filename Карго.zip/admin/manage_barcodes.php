<?php
session_start();
require '../config.php';
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

// Обработка удаления
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM barcodes WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    header("Location: manage_barcodes.php");
    exit;
}

// Обработка редактирования
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_id'])) {
    $id = (int)$_POST['edit_id'];
    $barcode = $_POST['barcode'];
    $status = $_POST['status'];
    $date = $_POST['date'];

    $stmt = $conn->prepare("UPDATE barcodes SET barcode = ?, status = ?, date = ? WHERE id = ?");
    $stmt->bind_param("sssi", $barcode, $status, $date, $id);
    $stmt->execute();
    $stmt->close();
    $message = "Штрих-код обновлен!";
}

// Обработка экспорта
if (isset($_GET['export'])) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="barcodes_' . date('Y-m-d_H-i-s') . '.csv"');
    $output = fopen('php://output', 'w');
    fputcsv($output, ['Штрих-код', 'Статус', 'Дата']);
    $where_clause = '';
    if (isset($_GET['search']) && !empty($_GET['search'])) {
        $search = mysqli_real_escape_string($conn, $_GET['search']);
        $where_clause = "WHERE barcode LIKE '%$search%' OR status LIKE '%$search%' OR date LIKE '%$search%'";
    }
    $barcodes = mysqli_query($conn, "SELECT barcode, status, date FROM barcodes $where_clause ORDER BY date DESC");
    while ($row = mysqli_fetch_assoc($barcodes)) {
        fputcsv($output, [$row['barcode'], $row['status'], $row['date']]);
    }
    fclose($output);
    exit;
}

// Обработка импорта
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['import_file'])) {
    $file = $_FILES['import_file'];
    if ($file['error'] == UPLOAD_ERR_OK && pathinfo($file['name'], PATHINFO_EXTENSION) === 'csv') {
        $handle = fopen($file['tmp_name'], 'r');
        $header = fgetcsv($handle); // Пропускаем заголовок
        $date = date('Y-m-d H:i:s');
        while (($data = fgetcsv($handle)) !== false) {
            if (count($data) >= 2) { // Минимально: штрих-код и статус
                $barcode = trim($data[0]);
                $status = trim($data[1]);
                $date_value = isset($data[2]) ? trim($data[2]) : $date;
                if (!empty($barcode) && !empty($status)) {
                    $stmt = $conn->prepare("INSERT IGNORE INTO barcodes (barcode, status, date) VALUES (?, ?, ?)");
                    $stmt->bind_param("sss", $barcode, $status, $date_value);
                    $stmt->execute();
                    $stmt->close();
                }
            }
        }
        fclose($handle);
        $message = "Импорт успешно завершён!";
    } else {
        $message = "Ошибка при импорте: загрузите корректный CSV-файл.";
    }
}

// Поиск
$search_query = '';
$where_clause = '';
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search = mysqli_real_escape_string($conn, $_GET['search']);
    $search_query = $search;
    $where_clause = "WHERE barcode LIKE '%$search%' OR status LIKE '%$search%' OR date LIKE '%$search%'";
}

$barcodes = mysqli_query($conn, "SELECT * FROM barcodes $where_clause ORDER BY date DESC");
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Список штрих-кодов - 9КМкарго</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <div class="container mt-5">
        <h1>Список штрих-кодов</h1>
        <?php if (isset($message)): ?>
            <div class="alert alert-<?php echo strpos($message, 'Ошибка') === false ? 'success' : 'danger'; ?>"><?php echo $message; ?></div>
        <?php endif; ?>
        <!-- Форма поиска -->
        <form method="GET" class="mb-4">
            <div class="input-group">
                <input type="text" name="search" class="form-control" placeholder="Поиск по штрих-коду, статусу или дате" value="<?php echo htmlspecialchars($search_query); ?>">
                <button type="submit" class="btn btn-primary"><i class="bi bi-search"></i> Найти</button>
                <?php if (!empty($search_query)): ?>
                    <a href="manage_barcodes.php" class="btn btn-secondary ms-2">Сбросить</a>
                <?php endif; ?>
            </div>
        </form>
        <!-- Кнопки экспорта и импорта -->
        <div class="mb-3">
            <a href="manage_barcodes.php?export=1<?php echo !empty($search_query) ? '&search='.urlencode($search_query) : ''; ?>" class="btn btn-success me-2">Экспорт в CSV</a>
            <form method="POST" enctype="multipart/form-data" class="d-inline">
                <input type="file" name="import_file" accept=".csv" class="form-control-file d-inline" style="display: inline-block; width: auto;">
                <button type="submit" class="btn btn-primary">Импорт из CSV</button>
            </form>
        </div>
        <!-- Таблица -->
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Штрих-код</th>
                    <th>Статус</th>
                    <th>Дата</th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                <?php if (mysqli_num_rows($barcodes) > 0): ?>
                    <?php while ($row = mysqli_fetch_assoc($barcodes)): ?>
                        <tr>
                            <td>
                                <?php if (isset($_GET['edit']) && $_GET['edit'] == $row['id']): ?>
                                    <form method="POST" class="d-inline">
                                        <input type="hidden" name="edit_id" value="<?php echo $row['id']; ?>">
                                        <input type="text" name="barcode" value="<?php echo htmlspecialchars($row['barcode']); ?>" class="form-control d-inline w-auto" required>
                                <?php else: ?>
                                    <?php echo htmlspecialchars($row['barcode']); ?>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (isset($_GET['edit']) && $_GET['edit'] == $row['id']): ?>
                                    <input type="text" name="status" value="<?php echo htmlspecialchars($row['status']); ?>" class="form-control d-inline w-auto" required>
                                <?php else: ?>
                                    <?php echo htmlspecialchars($row['status']); ?>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (isset($_GET['edit']) && $_GET['edit'] == $row['id']): ?>
                                    <input type="datetime-local" name="date" value="<?php echo str_replace(' ', 'T', $row['date']); ?>" class="form-control d-inline w-auto" required>
                                <?php else: ?>
                                    <?php echo $row['date']; ?>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (isset($_GET['edit']) && $_GET['edit'] == $row['id']): ?>
                                    <button type="submit" class="btn btn-success btn-sm">Сохранить</button>
                                    <a href="manage_barcodes.php" class="btn btn-secondary btn-sm">Отмена</a>
                                <?php else: ?>
                                    <a href="manage_barcodes.php?edit=<?php echo $row['id']; ?><?php echo !empty($search_query) ? '&search='.urlencode($search_query) : ''; ?>" class="btn btn-primary btn-sm">Редактировать</a>
                                    <a href="manage_barcodes.php?delete=<?php echo $row['id']; ?><?php echo !empty($search_query) ? '&search='.urlencode($search_query) : ''; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Удалить штрих-код?');">Удалить</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4" class="text-center">Штрих-коды не найдены.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <a href="index.php" class="btn btn-secondary">Назад</a>
    </div>
</body>
</html>