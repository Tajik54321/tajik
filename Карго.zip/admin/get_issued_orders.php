<?php
header('Content-Type: application/json');
require '../config.php';

$client_id = (int)($_GET['client_id'] ?? 0);
if ($client_id <= 0) {
    echo json_encode(['error' => 'Неверный ID клиента']);
    exit;
}

$result = mysqli_query($conn, "
    SELECT c.name as client_name, c.phone as client_phone
    FROM clients c
    WHERE c.id = $client_id
");
if ($client = mysqli_fetch_assoc($result)) {
    $orders = mysqli_query($conn, "
        SELECT co.weight, co.total_price, co.issued_at, b.barcode
        FROM client_orders co
        JOIN barcodes b ON co.barcode_id = b.id
        WHERE co.client_id = $client_id AND co.status = 'issued'
    ");

    $orders_array = [];
    $total_weight = 0;
    $total_price = 0;
    while ($order = mysqli_fetch_assoc($orders)) {
        $orders_array[] = $order;
        $total_weight += $order['weight'];
        $total_price += $order['total_price'];
    }

    echo json_encode([
        'client_name' => $client['client_name'],
        'client_phone' => $client['client_phone'],
        'orders' => $orders_array,
        'total_weight' => $total_weight,
        'total_price' => $total_price
    ]);
} else {
    echo json_encode(['error' => 'Клиент не найден']);
}
?>