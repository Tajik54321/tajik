<?php
session_start();
require '../config.php';
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

// Обработка удаления
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM news WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    header("Location: manage_news.php");
    exit;
}

// Обработка редактирования
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_id'])) {
    $id = (int)$_POST['edit_id'];
    $title = $_POST['title'];
    $content = $_POST['content'];
    $created_at = $_POST['created_at'];

    $stmt = $conn->prepare("UPDATE news SET title = ?, content = ?, created_at = ? WHERE id = ?");
    $stmt->bind_param("sssi", $title, $content, $created_at, $id);
    $stmt->execute();
    $stmt->close();
    $message = "Новость обновлена!";
}

$news = mysqli_query($conn, "SELECT * FROM news ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Управление новостями - 9КМкарго</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <div class="container mt-5">
        <h1>Управление новостями</h1>
        <?php if (isset($message)): ?>
            <div class="alert alert-success"><?php echo $message; ?></div>
        <?php endif; ?>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Заголовок</th>
                    <th>Содержание</th>
                    <th>Дата</th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($news)): ?>
                    <tr>
                        <td>
                            <?php if (isset($_GET['edit']) && $_GET['edit'] == $row['id']): ?>
                                <form method="POST" class="d-inline">
                                    <input type="hidden" name="edit_id" value="<?php echo $row['id']; ?>">
                                    <input type="text" name="title" value="<?php echo htmlspecialchars($row['title']); ?>" class="form-control d-inline w-auto" required>
                            <?php else: ?>
                                <?php echo htmlspecialchars($row['title']); ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if (isset($_GET['edit']) && $_GET['edit'] == $row['id']): ?>
                                <textarea name="content" class="form-control d-inline w-auto" required><?php echo htmlspecialchars($row['content']); ?></textarea>
                            <?php else: ?>
                                <?php echo htmlspecialchars($row['content']); ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if (isset($_GET['edit']) && $_GET['edit'] == $row['id']): ?>
                                <input type="datetime-local" name="created_at" value="<?php echo str_replace(' ', 'T', $row['created_at']); ?>" class="form-control d-inline w-auto" required>
                            <?php else: ?>
                                <?php echo $row['created_at']; ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if (isset($_GET['edit']) && $_GET['edit'] == $row['id']): ?>
                                <button type="submit" class="btn btn-success btn-sm">Сохранить</button>
                                <a href="manage_news.php" class="btn btn-secondary btn-sm">Отмена</a>
                            <?php else: ?>
                                <a href="manage_news.php?edit=<?php echo $row['id']; ?>" class="btn btn-primary btn-sm">Редактировать</a>
                                <a href="manage_news.php?delete=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Удалить новость?');">Удалить</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <a href="index.php" class="btn btn-secondary">Назад</a>
    </div>
</body>
</html>