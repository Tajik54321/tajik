<?php
session_start();
require '../config.php';
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $status = $_POST['status'];
    $date = $_POST['date'];

    $stmt = $conn->prepare("UPDATE barcodes SET status = ?, date = ? WHERE id = ?");
    $stmt->bind_param("ssi", $status, $date, $id);
    $stmt->execute();
    $stmt->close();
    $message = "Статус обновлен!";
}

$barcodes = mysqli_query($conn, "SELECT * FROM barcodes ORDER BY date DESC");
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Управление статусами</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>Управление статусами</h1>
        <?php if (isset($message)): ?>
            <div class="alert alert-success"><?php echo $message; ?></div>
        <?php endif; ?>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Штрих-код</th>
                    <th>Статус</th>
                    <th>Дата</th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($barcodes)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['barcode']); ?></td>
                        <td><?php echo htmlspecialchars($row['status']); ?></td>
                        <td><?php echo $row['date']; ?></td>
                        <td>
                            <form method="POST" class="d-inline">
                                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                <input type="text" name="status" value="<?php echo htmlspecialchars($row['status']); ?>" class="form-control d-inline w-auto" required>
                                <input type="datetime-local" name="date" value="<?php echo str_replace(' ', 'T', $row['date']); ?>" class="form-control d-inline w-auto" required>
                                <button type="submit" class="btn btn-primary btn-sm">Обновить</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <a href="index.php" class="btn btn-secondary">Назад</a>
    </div>
</body>
</html>