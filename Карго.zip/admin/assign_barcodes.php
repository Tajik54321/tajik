<?php
session_start();
require '../config.php';
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

// Поиск штрих-кодов
$search_query = '';
$where_clause = '';
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search = mysqli_real_escape_string($conn, $_GET['search']);
    $search_query = $search;
    $where_clause = "WHERE barcode LIKE '%$search%' OR status LIKE '%$search%' OR date LIKE '%$search%'";
}

$barcodes = mysqli_query($conn, "SELECT * FROM barcodes $where_clause ORDER BY date DESC");

// Сохранение заказа
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assign'])) {
    $client_name = $_POST['client_name'];
    $client_phone = $_POST['client_phone'];
    $barcode_ids = $_POST['barcode_ids'] ?? [];
    $weights = $_POST['weights'] ?? [];

    if (empty($client_name) || empty($client_phone) || empty($barcode_ids)) {
        $message = "Заполните все поля!";
    } else {
        // Сохранение клиента
        $stmt = $conn->prepare("INSERT INTO clients (name, phone) VALUES (?, ?)");
        $stmt->bind_param("ss", $client_name, $client_phone);
        $stmt->execute();
        $client_id = $conn->insert_id;
        $stmt->close();

        // Сохранение заказов
        $rate_per_kg = 10; // Пример: 10 единиц за 1 кг
        foreach ($barcode_ids as $index => $barcode_id) {
            $weight = floatval($weights[$index]);
            $total_price = $weight * $rate_per_kg;

            $stmt = $conn->prepare("INSERT INTO client_orders (client_id, barcode_id, weight, total_price) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("iidd", $client_id, $barcode_id, $weight, $total_price);
            $stmt->execute();
            $stmt->close();
        }
        $message = "Заказ успешно сохранён!";
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Выдача штрих-кодов - 9КМкарго</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <div class="container mt-5">
        <h1>Выдача штрих-кодов</h1>
        <?php if (isset($message)): ?>
            <div class="alert alert-<?php echo strpos($message, 'успешно') !== false ? 'success' : 'danger'; ?>"><?php echo $message; ?></div>
        <?php endif; ?>
        <!-- Поиск штрих-кодов -->
        <form method="GET" class="mb-4" id="searchForm">
            <div class="input-group">
                <input type="text" name="search" class="form-control" placeholder="Поиск по штрих-коду, статусу или дате" value="<?php echo htmlspecialchars($search_query); ?>">
                <button type="submit" class="btn btn-primary"><i class="bi bi-search"></i> Найти</button>
                <?php if (!empty($search_query)): ?>
                    <a href="assign_barcodes.php" class="btn btn-secondary ms-2">Сбросить</a>
                <?php endif; ?>
            </div>
        </form>
        <!-- Форма выдачи -->
        <form method="POST" id="assignForm">
            <div class="mb-3">
                <label for="client_name" class="form-label">Имя клиента:</label>
                <input type="text" name="client_name" id="client_name" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="client_phone" class="form-label">Номер телефона:</label>
                <input type="text" name="client_phone" id="client_phone" class="form-control" required>
            </div>
            <table class="table table-striped assign-barcodes-table">
                <thead>
                    <tr>
                        <th>Выбрать</th>
                        <th>Штрих-код</th>
                        <th>Статус</th>
                        <th>Дата</th>
                        <th>Вес (кг)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($barcodes) > 0): ?>
                        <?php while ($row = mysqli_fetch_assoc($barcodes)): ?>
                            <tr>
                                <td>
                                    <input type="checkbox" name="barcode_ids[]" value="<?php echo $row['id']; ?>" class="barcode-checkbox" data-id="<?php echo $row['id']; ?>">
                                </td>
                                <td><?php echo htmlspecialchars($row['barcode']); ?></td>
                                <td><?php echo htmlspecialchars($row['status']); ?></td>
                                <td><?php echo $row['date']; ?></td>
                                <td>
                                    <input type="number" step="0.01" name="weights[]" class="form-control weight-input" placeholder="Вес в кг">
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center">Штрих-коды не найдены.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <button type="submit" name="assign" class="btn btn-primary">Сохранить заказ</button>
        </form>
        <a href="index.php" class="btn btn-secondary mt-3">Назад</a>
    </div>

    <script>
        // Сохранение состояния чекбоксов и весов
        document.addEventListener('DOMContentLoaded', function() {
            const checkboxes = document.querySelectorAll('.barcode-checkbox');
            const weightInputs = document.querySelectorAll('.weight-input');

            // Восстановление состояния из localStorage
            const selectedBarcodes = JSON.parse(localStorage.getItem('selectedBarcodes') || '[]');
            const weights = JSON.parse(localStorage.getItem('weights') || '{}');

            checkboxes.forEach(checkbox => {
                if (selectedBarcodes.includes(checkbox.value)) {
                    checkbox.checked = true;
                }
                checkbox.addEventListener('change', saveSelections);
            });

            weightInputs.forEach((input, index) => {
                const barcodeId = checkboxes[index].value;
                if (weights[barcodeId]) {
                    input.value = weights[barcodeId];
                }
                input.addEventListener('input', saveSelections);
            });

            // При отправке формы поиска сохраняем выбранные штрих-коды
            document.getElementById('searchForm').addEventListener('submit', saveSelections);

            // При отправке формы выдачи очищаем localStorage
            document.getElementById('assignForm').addEventListener('submit', function() {
                localStorage.removeItem('selectedBarcodes');
                localStorage.removeItem('weights');
            });

            function saveSelections() {
                const selected = Array.from(checkboxes)
                    .filter(checkbox => checkbox.checked)
                    .map(checkbox => checkbox.value);
                localStorage.setItem('selectedBarcodes', JSON.stringify(selected));

                const weightData = {};
                weightInputs.forEach((input, index) => {
                    const barcodeId = checkboxes[index].value;
                    if (input.value) {
                        weightData[barcodeId] = input.value;
                    }
                });
                localStorage.setItem('weights', JSON.stringify(weightData));
            }
        });
    </script>
</body>
</html>