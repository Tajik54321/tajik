<?php
session_start();
require '../config.php';
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $barcodes_input = $_POST['barcodes_input'];
    $default_status = $_POST['default_status'] ?? ''; // Общий статус
    $lines = array_filter(array_map('trim', explode("\n", $barcodes_input))); // Разделяем по строкам и убираем пустые строки
    $date = date('Y-m-d H:i:s');
    $success_count = 0;
    $error_messages = [];

    foreach ($lines as $line) {
        $parts = array_map('trim', explode(',', $line)); // Разделяем строку на штрих-код и статус
        if (count($parts) < 1 || empty($parts[0])) {
            $error_messages[] = "Неверный формат строки: '$line'. Укажите хотя бы штрих-код.";
            continue;
        }

        $barcode = $parts[0];
        // Если статус указан в строке, используем его, иначе берём общий статус
        $status = (count($parts) > 1 && !empty($parts[1])) ? $parts[1] : $default_status;

        // Проверяем, указан ли статус (либо в строке, либо общий)
        if (empty($status)) {
            $error_messages[] = "Статус для штрих-кода '$barcode' не указан и общий статус не задан.";
            continue;
        }

        $stmt = $conn->prepare("INSERT INTO barcodes (barcode, status, date) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $barcode, $status, $date);
        if ($stmt->execute()) {
            $success_count++;
        } else {
            $error_messages[] = "Ошибка при добавлении штрих-кода '$barcode': " . $stmt->error;
        }
        $stmt->close();
    }

    if ($success_count > 0) {
        $message = "Успешно добавлено $success_count штрих-кодов.";
    }
    if (!empty($error_messages)) {
        $error_message = implode('<br>', $error_messages);
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Добавить штрих-код - 9КМкарго</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <div class="container mt-5">
        <h1>Добавить штрих-коды</h1>
        <?php if (isset($message)): ?>
            <div class="alert alert-success"><?php echo $message; ?></div>
        <?php endif; ?>
        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger"><?php echo $error_message; ?></div>
        <?php endif; ?>
        <form method="POST">
            <div class="mb-3">
                <label for="default_status" class="form-label">Общий статус (применяется, если статус не указан в строке):</label>
                <input type="text" name="default_status" id="default_status" class="form-control" placeholder="Например: в наличии">
            </div>
            <div class="mb-3">
                <label for="barcodes_input" class="form-label">Штрих-коды (в формате: штрих-код,статус):</label>
                <textarea name="barcodes_input" id="barcodes_input" class="form-control" rows="10" placeholder="Пример ввода:\n12345,в наличии\n67890,отправлен\n54321\n..." required></textarea>
                <small class="form-text text-muted">Каждая строка должна содержать штрих-код. Статус опционален (если не указан, используется общий статус).</small>
            </div>
            <button type="submit" class="btn btn-primary">Добавить</button>
            <a href="index.php" class="btn btn-secondary">Назад</a>
        </form>
    </div>
</body>
</html>