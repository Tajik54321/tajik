<?php
session_start();
require '../config.php';
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Админ-панель - 9КМкарго</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <div class="container mt-5">
        <h1>Админ-панель</h1>
        <div class="list-group">
            <a href="manage_barcodes.php" class="list-group-item list-group-item-action"><i class="bi bi-upc"></i> Список штрих-кодов</a>
            <a href="add_barcode.php" class="list-group-item list-group-item-action"><i class="bi bi-plus-circle"></i> Добавить штрих-код</a>
            <a href="manage_news.php" class="list-group-item list-group-item-action"><i class="bi bi-newspaper"></i> Управление новостями</a>
            <a href="add_news.php" class="list-group-item list-group-item-action"><i class="bi bi-plus-circle"></i> Добавить новость</a>
            <a href="assign_barcodes.php" class="list-group-item list-group-item-action"><i class="bi bi-box-arrow-up"></i> Выдача штрих-кодов</a>
            <a href="client_orders.php" class="list-group-item list-group-item-action"><i class="bi bi-person-lines-fill"></i> Заказы клиентов</a>
            <a href="logout.php" class="list-group-item list-group-item-action text-danger"><i class="bi bi-box-arrow-right"></i> Выход</a>
        </div>
    </div>
</body>
</html>