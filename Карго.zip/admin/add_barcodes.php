<?php
session_start();
require '../config.php';
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $barcodes = explode("\n", trim($_POST['barcodes']));
    $status = $_POST['status'];
    $date = date('Y-m-d H:i:s');

    foreach ($barcodes as $barcode) {
        $barcode = trim($barcode);
        if (!empty($barcode)) {
            $stmt = $conn->prepare("INSERT IGNORE INTO barcodes (barcode, status, date) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $barcode, $status, $date);
            $stmt->execute();
            $stmt->close();
        }
    }
    $message = "Штрих-коды добавлены!";
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Добавить штрих-коды</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>Добавить штрих-коды</h1>
        <?php if (isset($message)): ?>
            <div class="alert alert-success"><?php echo $message; ?></div>
        <?php endif; ?>
        <form method="POST">
            <div class="mb-3">
                <label>Штрих-коды (каждый с новой строки)</label>
                <textarea name="barcodes" class="form-control" rows="10" required></textarea>
            </div>
            <div class="mb-3">
                <label>Статус</label>
                <input type="text" name="status" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Добавить</button>
            <a href="index.php" class="btn btn-secondary">Назад</a>
        </form>
    </div>
</body>
</html>