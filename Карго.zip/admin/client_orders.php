<?php
session_start();
require '../config.php';
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

// Поиск клиентов
$search_query = '';
$where_clause = '';
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search = mysqli_real_escape_string($conn, $_GET['search']);
    $search_query = $search;
    $where_clause = "WHERE c.name LIKE '%$search%' OR c.phone LIKE '%$search%'";
}

$clients = mysqli_query($conn, "SELECT c.* FROM clients c $where_clause ORDER BY c.created_at DESC");

// Обновление статуса
if (isset($_GET['update_status']) && is_numeric($_GET['update_status'])) {
    $order_id = (int)$_GET['update_status'];
    $new_status = $_GET['status'] === 'issued' ? 'pending' : 'issued';
    $issued_at = $new_status === 'issued' ? date('Y-m-d H:i:s') : null;

    $stmt = $conn->prepare("UPDATE client_orders SET status = ?, issued_at = ? WHERE id = ?");
    $stmt->bind_param("ssi", $new_status, $issued_at, $order_id);
    $stmt->execute();
    $stmt->close();
    header("Location: client_orders.php");
    exit;
}

// Редактирование заказа
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_order'])) {
    $order_id = (int)$_POST['order_id'];
    $weight = floatval($_POST['weight']);
    $rate_per_kg = 10; // Пример: 10 единиц за 1 кг
    $total_price = $weight * $rate_per_kg;

    $stmt = $conn->prepare("UPDATE client_orders SET weight = ?, total_price = ? WHERE id = ?");
    $stmt->bind_param("ddi", $weight, $total_price, $order_id);
    $stmt->execute();
    $stmt->close();
    $message = "Заказ обновлён!";
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Заказы клиентов - 9КМкарго</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <div class="container mt-5">
        <h1>Заказы клиентов</h1>
        <?php if (isset($message)): ?>
            <div class="alert alert-success"><?php echo $message; ?></div>
        <?php endif; ?>
        <!-- Поиск клиентов -->
        <form method="GET" class="mb-4">
            <div class="input-group">
                <input type="text" name="search" class="form-control search-input" placeholder="Поиск по имени или номеру телефона" value="<?php echo htmlspecialchars($search_query); ?>">
                <button type="submit" class="btn btn-primary"><i class="bi bi-search"></i> Найти</button>
                <?php if (!empty($search_query)): ?>
                    <a href="client_orders.php" class="btn btn-secondary ms-2">Сбросить</a>
                <?php endif; ?>
            </div>
        </form>
        <!-- Список клиентов -->
        <div class="accordion" id="clientsAccordion">
            <?php while ($client = mysqli_fetch_assoc($clients)): ?>
                <div class="client-card">
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="heading-<?php echo $client['id']; ?>">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-<?php echo $client['id']; ?>" aria-expanded="false" aria-controls="collapse-<?php echo $client['id']; ?>">
                                Клиент: <?php echo htmlspecialchars($client['name']); ?> (<?php echo htmlspecialchars($client['phone']); ?>)
                            </button>
                        </h2>
                        <div id="collapse-<?php echo $client['id']; ?>" class="accordion-collapse collapse" aria-labelledby="heading-<?php echo $client['id']; ?>" data-bs-parent="#clientsAccordion">
                            <div class="accordion-body">
                                <?php
                                $orders = mysqli_query($conn, "SELECT co.*, b.barcode FROM client_orders co JOIN barcodes b ON co.barcode_id = b.id WHERE co.client_id = {$client['id']}");
                                $total_weight = 0;
                                $total_price = 0;
                                $pending_orders = [];
                                ?>
                                <table class="table table-striped client-orders-table">
                                    <thead>
                                        <tr>
                                            <th>Штрих-код</th>
                                            <th>Вес (кг)</th>
                                            <th>Сумма</th>
                                            <th>Статус</th>
                                            <th>Дата выдачи</th>
                                            <th>Действия</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while ($order = mysqli_fetch_assoc($orders)): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($order['barcode']); ?></td>
                                                <td>
                                                    <?php if (isset($_GET['edit_order']) && $_GET['edit_order'] == $order['id']): ?>
                                                        <form method="POST" class="d-inline">
                                                            <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                                            <input type="number" step="0.01" name="weight" value="<?php echo $order['weight']; ?>" class="form-control d-inline w-auto" required>
                                                    <?php else: ?>
                                                        <?php echo $order['weight']; ?>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo $order['total_price']; ?></td>
                                                <td><?php echo $order['status'] === 'pending' ? 'Ожидает выдачи' : 'Выдано'; ?></td>
                                                <td><?php echo $order['issued_at'] ?? '-'; ?></td>
                                                <td>
                                                    <?php if (isset($_GET['edit_order']) && $_GET['edit_order'] == $order['id']): ?>
                                                        <button type="submit" name="edit_order" class="btn btn-success btn-sm">Сохранить</button>
                                                        <a href="client_orders.php" class="btn btn-secondary btn-sm">Отмена</a>
                                                    <?php else: ?>
                                                        <a href="client_orders.php?edit_order=<?php echo $order['id']; ?>" class="btn btn-primary btn-sm no-print">Редактировать</a>
                                                        <?php if ($order['status'] === 'pending') $pending_orders[] = $order['id']; ?>
                                                        <a href="client_orders.php?update_status=<?php echo $order['id']; ?>&status=<?php echo $order['status']; ?>" class="btn btn-<?php echo $order['status'] === 'pending' ? 'success' : 'warning'; ?> btn-sm no-print">
                                                            <?php echo $order['status'] === 'pending' ? 'Выдать' : 'Отменить выдачу'; ?>
                                                        </a>
                                                        <button onclick="printSticker(<?php echo $order['id']; ?>)" class="btn btn-info btn-sm no-print">Печать</button>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                            <?php
                                            $total_weight += $order['weight'];
                                            $total_price += $order['total_price'];
                                            ?>
                                        <?php endwhile; ?>
                                        <tr>
                                            <td colspan="1"><strong>Итого:</strong></td>
                                            <td><strong><?php echo $total_weight; ?> кг</strong></td>
                                            <td><strong><?php echo $total_price; ?></strong></td>
                                            <td colspan="3"></td>
                                        </tr>
                                        <?php if (!empty($pending_orders)): ?>
                                            <tr>
                                                <td colspan="6">
                                                    <a href="client_orders.php?update_all_status=<?php echo $client['id']; ?>&status=issued" class="btn btn-success btn-sm no-print">Выдать все выбранные</a>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
        <a href="index.php" class="btn btn-secondary no-print">Назад</a>
    </div>

    <!-- Шаблон наклейки -->
    <div id="sticker-template" style="display: none;">
        <div class="sticker-content">
            <h4>9КМкарго - Наклейка</h4>
            <p><strong>Клиент:</strong> <span class="client-name"></span></p>
            <p><strong>Телефон:</strong> <span class="client-phone"></span></p>
            <p><strong>Штрих-код:</strong> <span class="barcode"></span></p>
            <p><strong>Вес:</strong> <span class="weight"></span> кг</p>
            <p><strong>Сумма:</strong> <span class="total"></span></p>
            <p><strong>Дата:</strong> <?php echo date('Y-m-d H:i:s'); ?></p>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Обновление статуса всех выбранных заказов
        document.addEventListener('DOMContentLoaded', function() {
            <?php if (isset($_GET['update_all_status']) && is_numeric($_GET['update_all_status'])): ?>
                const clientId = <?php echo (int)$_GET['update_all_status']; ?>;
                const status = '<?php echo $_GET['status']; ?>';
                const issued_at = status === 'issued' ? '<?php echo date('Y-m-d H:i:s'); ?>' : null;

                fetch(`client_orders.php?update_all_status=${clientId}&status=${status}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                })
                .then(response => response.text())
                .then(() => location.reload());
            <?php endif; ?>
        });

        function printSticker(orderId) {
            fetch('get_order.php?order_id=' + orderId)
                .then(response => response.json())
                .then(data => {
                    const template = document.getElementById('sticker-template').innerHTML;
                    const printWindow = window.open('', '_blank');
                    printWindow.document.write(`
                        <html>
                        <head>
                            <title>Печать наклейки</title>
                            <link href="../css/style.css" rel="stylesheet">
                        </head>
                        <body>
                            <div class="sticker-content">
                                <h4>9КМкарго - Наклейка</h4>
                                <p><strong>Клиент:</strong> ${data.client_name}</p>
                                <p><strong>Телефон:</strong> ${data.client_phone}</p>
                                <p><strong>Штрих-код:</strong> ${data.barcode}</p>
                                <p><strong>Вес:</strong> ${data.weight} кг</p>
                                <p><strong>Сумма:</strong> ${data.total_price}</p>
                                <p><strong>Дата:</strong> ${new Date().toLocaleString()}</p>
                            </div>
                            <script>window.print(); window.close();<\/script>
                        </body>
                        </html>
                    `);
                    printWindow.document.close();
                });
        }
    </script>
</body>
</html>