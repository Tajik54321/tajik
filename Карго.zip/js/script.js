document.getElementById('barcodeForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const barcodes = document.getElementById('barcodes').value;
    fetch('check_barcode.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'barcodes=' + encodeURIComponent(barcodes)
    })
    .then(response => response.json())
    .then(data => {
        const result = document.getElementById('result');
        if (data.error) {
            result.innerHTML = `<div class="alert alert-danger">${data.error}</div>`;
        } else {
            let output = '<h4>Результаты проверки:</h4>';
            for (const barcode in data) {
                if (data[barcode].error) {
                    output += `
                        <div class="alert alert-danger">
                            <p><strong>Штрих-код:</strong> ${barcode}</p>
                            <p>${data[barcode].error}</p>
                        </div>`;
                } else {
                    output += `
                        <div class="alert alert-success">
                            <p><strong>Штрих-код:</strong> ${data[barcode].barcode}</p>
                            <p><strong>Статус:</strong> ${data[barcode].status}</p>
                            <p><strong>Дата:</strong> ${data[barcode].date}</p>
                        </div>`;
                }
            }
            result.innerHTML = output;
        }
    })
    .catch(error => {
        document.getElementById('result').innerHTML = `<div class="alert alert-danger">Ошибка: ${error.message}</div>`;
    });
});